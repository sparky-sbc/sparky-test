sudo insmod wlan_8812au.ko 
sudo depmod -a

