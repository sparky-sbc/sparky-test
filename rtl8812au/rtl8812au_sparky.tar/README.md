this driver buid for testing rtl8812au wifi module on sparky 3.10.38 kernel

steps
*********
ssh ogin to sparky 
cd /usr/src/
wget https://raw.githubusercontent.com/sparky-sbc/sparky-test/master/rtl8812au/rtl8812au_sparky.tar
tar -xvf rtl8812au_sparky.tar
./install.sh


