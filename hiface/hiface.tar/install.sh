#!/bin/sh
sudo mkdir /lib/modules/3.10.38/kernel/sound/usb/hiface
cp snd-usb-hiface.ko /lib/modules/3.10.38/kernel/sound/usb/hiface/
sudo depmod -a
sudo modprobe snd-usb-hiface
exit 0
