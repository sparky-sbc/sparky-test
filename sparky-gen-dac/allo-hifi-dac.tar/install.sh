#!/bin/sh
sudo rm -rf /lib/modules/3.10.38/kernel/sound/soc/codecs/
mkdir /lib/modules/3.10.38/kernel/sound/soc/codecs/
sudo cp snd-soc-pcm5102a.ko /lib/modules/3.10.38/kernel/sound/soc/codecs/
sudo cp snd-soc-allo-hifi-dac.ko /lib/modules/3.10.38/kernel/sound/soc/atc260x/
sudo insmod /lib/modules/3.10.38/kernel/sound/soc/codecs/snd-soc-pcm5102a.ko
sudo insmod /lib/modules/3.10.38/kernel/sound/soc/atc260x/snd-soc-allo-hifi-dac.ko
sudo depmod -a
echo '# /etc/modules: kernel modules to load at boot time' > /etc/modules
echo '# at boot time, one per line. Lines beginning with "#" are ignored.' >>  /etc/modules
echo snd-soc-pcm5102a >>  /etc/modules
echo snd-soc-allo-hifi-dac >>  /etc/modules  
