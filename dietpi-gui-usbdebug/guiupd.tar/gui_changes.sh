mv guiupd /usr/src/changes
cp /usr/src/changes/UserController.php /var/www/allo/app/Http/Controllers/UserController.php
cp /usr/src/changes/web.php /var/www/allo/routes/web.php
cp /usr/src/changes/squeezelite_settings.blade.php /var/www/allo/resources/views/frontend/squeezelite_settings.blade.php 
cp /usr/src/changes/status.blade.php /var/www/allo/resources/views/frontend/status.blade.php
