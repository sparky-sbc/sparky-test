<?php

namespace App\Http\Controllers;

use Redirect;
use App\User;
use Auth;
use DB;
use Cookie;
use App\Mail\ResetPassword;
use Illuminate\Http\Request;

class UserController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    public function mpdSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $mpdstatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active mpd.service | grep -ci -m1 '^active'");
        if ($mpdstatus == 0) {
            $mpd_status = 'Inactive';
        } elseif ($mpdstatus == 1) {
            $mpd_status = 'Active';
        }

        $ipaddress = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -n 4p /DietPi/dietpi/.network");
        $current_date = date("M d, Y");
        $current_time = date("h:i a");
        $soxr_status = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -ci -m1 '^samplerate_converter \"soxr' /etc/mpd.conf");

		$mpdNativeOutput = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -ci -m1 '^#format ' /etc/mpd.conf");
		if ($mpdNativeOutput == 1) {
			$outputFrequencies = 'Native';
			$bitDepth = 'Native';
		} else {
			$outputFrequencies = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'format ' /etc/mpd.conf | sed 's/\"//g' | sed 's/:/ /g' | awk '{print $2}'");
			$bitDepth = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'format ' /etc/mpd.conf | sed 's/\"//g' | sed 's/:/ /g' | awk '{print $3}'");
		}
        $urlLink = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo http://'$ipaddress'/ompd");

        $soxrQuality = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'samplerate_converter \"soxr' /etc/mpd.conf | sed 's/\"//g'");

        return view('frontend.mpd_settings')->with(['mpd_status' => $mpd_status, 'soxrQuality' => $soxrQuality,
            'outputFrequencies' => $outputFrequencies, 'bitDepth' => $bitDepth, 'current_date' => $current_date,
            'current_time' => $current_time, 'urlLink' => $urlLink, 'soxr_status' => $soxr_status, 'ipaddress' => $ipaddress]);
    }

    public function changeMpdSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $mpd_status = $request->mpd;
        $soxr_status = $request->soxrStatus;
        $bitDepth = $request->bitDepth;
        $frequency = $request->frequency;
        $soxrQuality = $request->soxrQuality;

        // if disabled, status = yes ; if enabled, status = no
        if ($mpd_status == 'yes') {

            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop mpd.service; sudo systemctl mask mpd.service");

        } elseif ($mpd_status == 'no') {

			if ($soxr_status == 'yes') {

				$ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/samplerate_converter \"/c\#samplerate_converter \"soxr high" /etc/mpd.conf');

			} elseif ($soxr_status == 'no') {

				$quality = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/samplerate_converter \"/c\samplerate_converter \"soxr ' . $soxrQuality . '\"" /etc/mpd.conf');

			}

			// Reset, enable if commented out.
			//	0 = native
			$ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^format \"/c\format \"0:0:2\"" /etc/mpd.conf');
			$ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^#format \"/c\format \"0:0:2\"" /etc/mpd.conf');
			if ($frequency == 'Native' || $bitDepth == 'Native') {

				$chngOutputFrequency = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^format \"/c\#format \"0:0:2\"" /etc/mpd.conf');

			} else {

				$chngOutputFrequency = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^format \"/c\format \"' . $frequency . ':' . $bitDepth . ':2\"" /etc/mpd.conf');

			}

			$ssh->exec("sudo systemctl unmask mpd.service; sudo systemctl restart mpd.service");

        }

        return redirect('/user/mpd_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function roonSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $roonStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active roonbridge.service | grep -ci -m1 '^active'");
        return view('frontend.roon_settings')->with(['current_date' => $current_date, 'roonStatus' => $roonStatus]);
    }

    public function changeRoonSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $roon = $request->roon;

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes

        if ($roon == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop roonbridge.service; sudo mv /etc/systemd/system/roonbridge.service /etc/systemd/system/roonbridge.service.disable; sudo systemctl daemon-reload");
        } elseif ($roon = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo mv /etc/systemd/system/roonbridge.service.disable /etc/systemd/system/roonbridge.service; sudo systemctl daemon-reload; sudo systemctl start roonbridge.service");
        }
        return redirect('/user/roon_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function gmrenderSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $gmrenderStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active gmrender.service | grep -ci -m1 '^active'");
        return view('frontend.gmrender_settings')->with(['current_date' => $current_date, 'gmrenderStatus' => $gmrenderStatus]);
    }

    public function changeGmrenderSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $gmrenderStatus = $request->gmrenderStatus;

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes

        if ($gmrenderStatus == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop gmrender.service; sudo mv /etc/systemd/system/gmrender.service /etc/systemd/system/gmrender.service.disable; sudo systemctl daemon-reload");
        } elseif ($gmrenderStatus = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo mv /etc/systemd/system/gmrender.service.disable /etc/systemd/system/gmrender.service; sudo systemctl daemon-reload; sudo systemctl start gmrender.service");
        }
        return redirect('/user/gmrender_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function netdataSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $netdataStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active netdata.service | grep -ci -m1 '^active'");
		$ipLocal = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -n 4p /DietPi/dietpi/.network");

        return view('frontend.netdata_settings')->with(['current_date' => $current_date, 'netdataStatus' => $netdataStatus, 'ipLocal'=>$ipLocal]);
    }

    public function changeNetdataSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $netdataStatus = $request->netdataStatus;

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes
		if ($netdataStatus == 'yes') {
             $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop netdata.service; sudo mv /etc/systemd/system/netdata.service /etc/systemd/system/netdata.service.disable; sudo systemctl daemon-reload");
        } elseif ($netdataStatus = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo mv /etc/systemd/system/netdata.service.disable /etc/systemd/system/netdata.service; sudo systemctl daemon-reload; sudo systemctl start netdata.service");
        }
        return redirect('/user/netdata_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function squeezeliteSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $squeezeliteStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active squeezelite.service | grep -ci -m1 '^active'");

		if (file_exists('/etc/systemd/system/squeezelite.service'))
		{
			$bitDepth = (string) trim($ssh->exec("sudo grep -m1 '^ExecStart=' /etc/systemd/system/squeezelite.service | awk '{print $3}' | sed 's/:/ /g' | awk '{print $3}'"));
			$DSD_NATIVE = (string) trim($ssh->exec("sudo grep -m1 '^ExecStart=' /etc/systemd/system/squeezelite.service | awk '{print $11}' | sed 's/://g'"));
			if ( ! $DSD_NATIVE )
			{
				$DSD_NATIVE = 'disabled';
			}

		}
		else
		{
			$bitDepth = 16;
			$DSD_NATIVE = 'disabled';
		}

        return view('frontend.squeezelite_settings')->with(['current_date' => $current_date, 'squeezeliteStatus' => $squeezeliteStatus, 'bitDepth'=>$bitDepth, 'DSD_NATIVE'=>$DSD_NATIVE]);
    }

    public function changeSqueezeliteSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $squeezeliteStatus = $request->squeezeliteStatus;

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes
		if ($squeezeliteStatus == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop squeezelite.service; sudo mv /etc/systemd/system/squeezelite.service /etc/systemd/system/squeezelite.service.disable; sudo systemctl daemon-reload");
        } elseif ($squeezeliteStatus = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo mv /etc/systemd/system/squeezelite.service.disable /etc/systemd/system/squeezelite.service");
			$bitDepth = $request->bitDepth;
			$DSD_NATIVE = $request->DSD_NATIVE;
			if ( $DSD_NATIVE == 'disabled' )
			{
				$chngbitDepth = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^ExecStart=/c\ExecStart=/usr/bin/squeezelite -a 4096:8096:' . $bitDepth . ':0 -C 5 -n \'DietPi-Squeezelite\' -f /var/log/squeezelite.log" /etc/systemd/system/squeezelite.service;');
			}
			else
			{
				$chngbitDepth = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/^ExecStart=/c\ExecStart=/usr/bin/squeezelite -a 4096:8096:' . $bitDepth . ':0 -C 5 -n \'DietPi-Squeezelite\' -f /var/log/squeezelite.log -D :' . $DSD_NATIVE . '" /etc/systemd/system/squeezelite.service;');
			}
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl daemon-reload; sudo systemctl restart squeezelite.service");
        }

        return redirect('/user/squeezelite_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function shairPortSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $shairPortStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active shairport-sync.service | grep -ci -m1 '^active'");
        $outputFrequencies = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'output_rate' /usr/local/etc/shairport-sync.conf | sed 's/\///g' | awk '{print $3}' | sed 's/\;//g'");
        $bitDepth = (string) trim($ssh->exec("sudo grep -m1 'output_format' /usr/local/etc/shairport-sync.conf | sed 's/\///g' | awk '{print $3}' | sed 's/\;//g' | sed 's/\"//g' | sed 's/S//g'"));

        return view('frontend.shair_port_settings')->with(['current_date' => $current_date, 'shairPortStatus' => $shairPortStatus, 'outputFrequencies' => $outputFrequencies, 'bitDepth' => $bitDepth]);
    }

    public function changeshairPortSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $shairPort = $request->shairPort;
        $bitDepth = $request->bitDepth;
        $frequency = $request->frequency;

        $chngOutputFrequency = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/output_rate /c\output_rate = ' . $frequency . ';" /usr/local/etc/shairport-sync.conf' );
        $chngbitDepth = $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo sed -i "/output_format /c\output_format = \"S' . $bitDepth . '\";" /usr/local/etc/shairport-sync.conf');

        if ($shairPort == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop shairport-sync.service; sudo systemctl mask shairport-sync.service");
        } elseif ($shairPort = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl unmask shairport-sync.service; sudo systemctl restart shairport-sync.service");
        }

        return redirect('/user/shair_port_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function daemonSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $daemonStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active networkaudiod.service | grep -ci -m1 '^active'");
        return view('frontend.daemon_settings')->with(['current_date' => $current_date, 'daemonStatus' => $daemonStatus]);
    }

    public function changeDaemonSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $daemon = $request->daemon;

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes

        if ($daemon == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop networkaudiod.service; sudo systemctl mask networkaudiod.service");
        } elseif ($daemon = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl unmask networkaudiod.service; sudo systemctl start networkaudiod.service");
        }
        return redirect('/user/daemon_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function wifiSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $current_date = date("M d, Y");
        $wifiStatus = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl is-active hostapd.service | grep -ci -m1 '^active'");
        $currentSSID = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 '^ssid=' /etc/hostapd/hostapd.conf | sed 's/.*=//'");
        $currentPasskey = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 '^wpa_passphrase=' /etc/hostapd/hostapd.conf | sed 's/.*=//'");
        $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl restart hostapd.service");
        return view('frontend.wifi_settings')->with(['current_date' => $current_date, 'wifiStatus' => $wifiStatus, 'currentSSID' => $currentSSID, 'currentPasskey' => $currentPasskey]);
    }

    public function changeWifiSettings(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $currentSSID = $request->wifiSsid;
        $wifiStatus = $request->wifiStatus;
        $currentPasskey = $request->wifiPasskey;

        // for changing ssid
        $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -i '/ssid=/c\ssid=$currentSSID' /etc/hostapd/hostapd.conf");

        //for changing passkey
        $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -i '/wpa_passphrase=/c\wpa_passphrase=$currentPasskey' /etc/hostapd/hostapd.conf");

        // if status to be enabled ,status = no ; if status to be disabled ,status = yes

        if ($wifiStatus == 'yes') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl stop hostapd.service; sudo systemctl mask hostapd.service");
        } elseif ($wifiStatus = 'no') {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl unmask hostapd.service; sudo systemctl start hostapd.service");
        }

        $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl restart hostapd.service");
        return redirect('/user/wifi_settings')->with(['custom_message' => 'Successfully updated']);
    }

    public function download(Request $request) {
	include(app_path() . "/phpseclib/Net/SSH2.php");
	$ssh = new \phpseclib\Net\SSH2('localhost');
	$ssh->login('allo', 'allo') or die("Login failed");
	$ipLocal = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -n 4p /DietPi/dietpi/.network");
	$current_date = date("M d, Y");
	unset($output);
	$file_name = "/tmp/Sound_Card_Status.txt";
	$output = "\n\n----- SOUND CARD STATUS -----\n\n";
	$output = "\n\n----- USB DAC INFO -----\n\n";
	$output .= $ssh->exec("lsusb");
	$output .= "\n\n---- USB PORT INFO----\n\n";
	$output .= $ssh->exec("lsusb -t");
	$output .= "\n\n---- SOUND CARDS INFO----\n\n";
	$hw_param = $ssh->exec("cat /proc/asound/card1/stream0");
	if(preg_match('/\bNo such file or directory\b/',$hw_param)) {
		$hw_param = "NO SOUND CARDS";
	}
	$output .= $hw_param;
	$output .= "\n\n---- APLAY INFO ----\n\n";
	$output .= $ssh->exec("sudo aplay -l");
	$output .= "\n\n---- DMESG INFO ----\n\n";
	$output .= $ssh->exec("dmesg");
	$output .= "\n\n\n--------------*******-----------\n\n";
	if (file_exists($file_name)) {
		$del_tmp_file = $ssh->exec("rm $file_name");
	}
	$myfile = fopen($file_name, "w") or die("Unable to open file!");
	fwrite($myfile, $output);
	fclose($myfile);
	if (file_exists($file_name) && is_readable($file_name)) {
		header('Content-Description: File Transfer');
		header('Content-Type: application/txt');
		header("Content-Disposition: attachment; filename=\"Sound_Card_Status.txt\"");
		readfile($file_name);
	} else {
		header("HTTP/1.0 404 Not Found");
		echo "<h1>Error 404: File Not Found: <br /><em>Sound_Card_Status</em></h1>";
	}
    }

    public function status(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");


        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
		$ipLocal = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -n 4p /DietPi/dietpi/.network");
		$current_date = date("M d, Y");
        $status = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo cat /proc/asound/card*/pcm0p/sub0/hw_params");
        $cpu_temp = $ssh->exec("TERM=linux G_USER_INPUTS=0 . /DietPi/dietpi/func/dietpi-globals; G_OBTAIN_CPU_TEMP");
        $cpu_usage = $ssh->exec("TERM=linux G_USER_INPUTS=0 . /DietPi/dietpi/func/dietpi-globals; G_OBTAIN_CPU_USAGE");
        $total_memory = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo echo -e \"$(( $( grep -m1 'MemTotal:' /proc/meminfo | awk '{print $2}') / 1000 ))\"");
        $free_memory = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo echo -e \"$(( $( grep -m1 'MemFree:' /proc/meminfo | awk '{print $2}') / 1000 ))\"");

        $memory_usage = intval($total_memory) - intval($free_memory);

        $memory_usage_perc = intval($memory_usage) * 100 /intval($total_memory);
        $total_storage = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo df -B M | grep -m1 '/$' | awk '{print $2}' | sed 's/[^0-9]//g'");
        $free_storage = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo df -B M | grep -m1 '/$' | awk '{print $4}' | sed 's/[^0-9]//g'");
        $storage_usage = intval($total_storage) - intval($free_storage);
        $storage_usage_perc = intval($storage_usage) * 100 /intval($total_storage);
        $alsaInfo = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo cat /proc/asound/card*/pcm0p/sub0/hw_params | sed ':a;N;$!ba;s/\'n'/ | /g'");
        $alsaInfo = ltrim($alsaInfo, 'closed |');
        $lsusb = $ssh->exec("lsusb");
	$lsusb_port = $ssh->exec("lsusb -t");
	$hw_param = $ssh->exec("cat /proc/asound/card1/stream0");
	if(preg_match('/\bNo such file or directory\b/',$hw_param)) {
		$hw_param = "No Sound Cards";
	}
	$aplay = $ssh->exec("sudo aplay -l");
	$dmesg = $ssh->exec("dmesg");
	return view('frontend.status')->with(['ipLocal' => $ipLocal, 'current_date' => $current_date, 'status' => $status,'cpu_temp'=>$cpu_temp, 'cpu_usage'=>$cpu_usage,'total_memory'=>$total_memory,'free_memory'=>$free_memory,'memory_usage'=>$memory_usage, 'memory_usage_perc'=>$memory_usage_perc,'total_storage'=>$total_storage,'free_storage'=>$free_storage, 'storage_usage'=>$storage_usage,'storage_usage_perc'=>$storage_usage_perc,'alsaInfo'=>$alsaInfo,'lsusb'=>$lsusb,'lsusb_port'=>$lsusb_port, 'hw_param'=>$hw_param, 'aplay'=>$aplay, 'dmesg'=>$dmesg]); 
    }

     public function systemSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $selected = $request->get('selected');
        $selected = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -ci -m1 'iface eth0 inet dhcp' /etc/network/interfaces");
        $ipaddress = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo ip a s eth0 | grep -m1 '^[[:blank:]]*inet ' | awk '{ print $2 }' | sed 's|/.*$||'");
        $current_date = date("M d, Y");
        $current_time = date("h:i a");
        $soundCard = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'CONFIG_SOUNDCARD=' /DietPi/dietpi.txt | sed 's/.*=//'");
        $hostName = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo cat /etc/hostname");
        $ipGateway = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo ip r | grep -m1 'default' | awk '{ print $3 }'");
        $ipMask = '255.255.255.0';
        $ipDns = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 'nameserver' /etc/resolv.conf | awk '{print $2}'");
        $soundCard = preg_replace('/\s+/', '', $soundCard);
        $cpuGovernor = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 '^CONFIG_CPU_GOVERNOR=' /DietPi/dietpi.txt | sed 's/.*=//'");
        $cpuGovernor = preg_replace('/\s+/', '', $cpuGovernor);
        $updateDietPiStatus = $ssh->exec("if [ -f /DietPi/dietpi/.update_available ]; then cat /DietPi/dietpi/.update_available; fi");
        $currentversionDietPi = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo echo -e \"$(grep -m1 'G_DIETPI_VERSION_CORE' /DietPi/dietpi/.version | sed 's/.*=//').$(grep -m1 'G_DIETPI_VERSION_SUB' /DietPi/dietpi/.version | sed 's/.*=//').$(grep -m1 'G_DIETPI_VERSION_RC' /DietPi/dietpi/.version | sed 's/.*=//')\"");
        $HW_MODEL = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -n 1p /DietPi/dietpi/.hw_model");
        $rangeVal = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 '^AUTO_SETUP_SWAPFILE_SIZE=' /DietPi/dietpi.txt | sed 's/.*=//'");

        return view('frontend.system_settings')->with(['ipAddress' => $ipaddress, 'soundCard' => $soundCard,
            'hostName' => $hostName,'ipGateway' => $ipGateway, 'ipMask' => $ipMask, 'ipDns' => $ipDns,
            'current_date' => $current_date,'current_time' => $current_time, 'selectoption' => $selected,
            'updateDietPiStatus' => $updateDietPiStatus, 'currentversionDietPi' => $currentversionDietPi,'cpuGovernor' => $cpuGovernor,'HW_MODEL' => $HW_MODEL,'rangeVal' => $rangeVal]);
    }

    public function changeSystemSettings(Request $request) {

        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $ip = $request->IP;
        $host = $request->host;
        $address = $request->address;
        $gateway = $request->gateway;
        $mask = $request->mask;
        $dns = $request->dns;
        $chag_sort = $request->chag_sort;
        $soundcard = $request->soundcard;
        $cpuGovernor = $request->cpuGovernor;

        if(isset($host) && !empty($host)) {
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_hardware soundcard $soundcard");
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/change_hostname $host");
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_dphys-swapfile $chag_sort");
            $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sed -i '/CONFIG_CPU_GOVERNOR=/c\CONFIG_CPU_GOVERNOR=$cpuGovernor' /DietPi/dietpi.txt; sudo /DietPi/dietpi/func/dietpi-set_cpu");
            if($ip=='dhcp') {
                $ssh->exec('TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_software allo eth_dhcp');
                $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl daemon-reload");
            }
            else {
                $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_software allo eth_static $address $gateway $mask $dns");
                $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo systemctl daemon-reload");
            }
        } else {
            return redirect('/user/system_settings')->with(['custom_message' => 'Please enter the hostname']);
        }

        return redirect('/user/system_settings')->with(['custom_message' => '<p>NB: If any of the following items have been changed, please reboot your system to apply the new settings:</p>
            <ul>
                <li>
                    IP Address Change (DHCP/STATIC)
                </li>
                <li>
                    Hostname
                </li>
                <li>
                    Soundcard Selection
                </li>
                <li>
                    Update DietPi
                </li>
            </ul>'
        ]);
    }

    public function updateDietPi(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
		$ssh->setTimeout(0);
        $update = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/dietpi-update 1");
        return 1;
    }

    public function reeboot(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
		$ssh->setTimeout(1);
        $update = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo sleep 3; sudo reboot");
        return 1;
    }

    public function power(Request $request) {
        include(app_path() . "/phpseclib/Net/SSH2.php");

        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $update = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo poweroff");
        return 1;
    }


    public function swapFileSize(Request $request) {
        $val = $request->val;
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_dphys-swapfile $val");
        $success = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo grep -m1 '^CONF_SWAPSIZE=' /etc/dphys-swapfile | sed 's/.*=//'");
        return $success;
    }

    public function updateSoundCard(Request $request) {
        $val = $request->val;
        include(app_path() . "/phpseclib/Net/SSH2.php");
        $ssh = new \phpseclib\Net\SSH2('localhost');
        $ssh->login('allo', 'allo') or die("Login failed");
        $success = $ssh->exec("TERM=linux G_USER_INPUTS=0 sudo /DietPi/dietpi/func/dietpi-set_hardware soundcard $val");
        return $success;
    }

}
